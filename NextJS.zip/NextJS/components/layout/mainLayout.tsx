import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { connect } from 'react-redux';
import Tabbar from 'components/tabbar';
import Navbar from 'components/navbar';
import { useDevice } from 'shared/HOOK/useSize';

type Props = {
  headData?: any;
  children: any;
  customClass?: string;
  menuExpanded?: boolean;
};
const MainLayout = (props: Props) => {
  const { children, customClass, menuExpanded } = props;
  const isMobile = useDevice('mobile');

  return (
    <Fragment>
      <Navbar isAuth={false} isMobile={isMobile} />
      <main id="mainLayout" className={`main-container ${customClass}`}>
        <div id="wrapper" className={`${menuExpanded ? '' : 'left-side-menu-condensed'}`}>
          {children}
        </div>
      </main>
      <Tabbar />
    </Fragment>
  );
};

MainLayout.propTypes = {
  menuExpanded: PropTypes.bool,
};

MainLayout.defaultProps = {
  menuExpanded: true,
};

const mapStateToProps = (state: any) => ({
  menuExpanded: state.menuReducer.isExpanded,
});

const withConnect = connect(mapStateToProps);

export default compose(withConnect)(MainLayout);
