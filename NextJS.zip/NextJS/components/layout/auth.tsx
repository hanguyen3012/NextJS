import React, { Fragment } from 'react';
import { connect } from 'react-redux';
import Tabbar from 'components/tabbar';
import Navbar from 'components/navbar';
import { useDevice } from 'shared/HOOK/useSize';

type AuthLayoutProps = {
  children: any;
};

const AuthLayout = (props: AuthLayoutProps) => {
  const isMobile = useDevice('mobile');
  const children = props.children || null;
  return (
    <Fragment>
      <Navbar isAuth={true} isMobile={isMobile} />
      {children}
      <Tabbar />
    </Fragment>
  );
};

export default connect()(AuthLayout);
