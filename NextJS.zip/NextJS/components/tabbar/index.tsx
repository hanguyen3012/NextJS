import React, { useState } from 'react';
import { Tabs } from 'antd-mobile';

const tabs: any = [{ title: 'logo' }, { title: 'First Tab' }, { title: 'Second Tab' }, { title: 'Third Tab' }];

function TabBar() {
  return (
    <div style={{ position: 'fixed', bottom: 0, width: '100%' }}>
      <Tabs
        tabs={tabs}
        initialPage={1}
        tabBarPosition="bottom"
        onChange={(tab, index) => {
          console.log('onChange', index, tab);
        }}
        onTabClick={(tab, index) => {
          console.log('onTabClick', index, tab);
        }}
      />
    </div>
  );
}

export default TabBar;
