import React from 'react';
import { useTranslation } from 'i18next-config';
import { useDispatch } from 'react-redux';
import { AUTH_PAGE, USER_TYPE } from 'shared/constant/common';
import { openModal } from 'redux/actions';

type FooterModalType = {
  isRegister?: boolean;
  type?: string;
  changeType?: any;
};

const FooterModal = (props: FooterModalType) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();

  const showAuth = () => {
    if (props.isRegister) {
      dispatch(openModal(AUTH_PAGE.SIGN_UP_EMAIL));
    } else {
      dispatch(openModal(AUTH_PAGE.LOGIN));
    }
  };

  return (
    <>
      <div className="d-flex flex-column justify-content-center align-items-center font-size-10 line-height-12 text-normal">
        <div className="width-155 mg-t-5 mg-b-5" style={{ backgroundColor: '#838383', height: '1px' }}></div>
        <p className="mg-b-0 modal-line-height-footer">
          {props.isRegister ? t('auth:have_not_registered_yet') : t('auth:already_registered')}&ensp;
          <span className="color-primary" onClick={showAuth}>
            {props.isRegister ? t('auth:register_now') : t('auth:login_now')}
          </span>
        </p>
        <p className="mg-b-0 modal-line-height-footer">
          {props.type === USER_TYPE.SALON ? t('auth:are_you_an_applicant') : t('auth:are_you_a_salon')}&ensp;
          <span className="color-primary" onClick={() => props.changeType(props.type)}>
            {t('auth:get_started_here')}
          </span>
        </p>
      </div>
    </>
  );
};

export default FooterModal;
