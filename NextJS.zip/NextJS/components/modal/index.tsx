import React, { useEffect, useState } from 'react';
import { Modal } from 'antd-mobile';
import { connect } from 'react-redux';

import { AUTH_PAGE } from 'shared/constant/common';
import Login from './Login';
import VerifyRegister from './Verify-Register';
import Register from './Register';
import RegisterPassword from './RegisterPassword';
import ForgotPassword from './Forgot-Password';
import ResetPassword from './Reset-Password';
import Alert from './Alert';

const ModalPopup = (props: any) => {
  const [modal, setModal] = useState(false);
  const [page, setPage] = useState('');

  useEffect(() => {
    setModal(props.isModalOpen);
    setPage(props.page);
  }, [props.isModalOpen, props.page]);

  const onCloseModal = () => {
    setModal(false);
  };

  const ModalAuth = () => {
    switch (page) {
      case AUTH_PAGE.LOGIN:
        return <Login />;
      case AUTH_PAGE.VERIFY_EMAIL_REGISTER:
        return <VerifyRegister />;
      case AUTH_PAGE.SIGN_UP_EMAIL:
        return <Register />;
      case AUTH_PAGE.SIGN_UP_PASSWORD:
        return <RegisterPassword />;
      case AUTH_PAGE.FORGOT_PASSWORD:
        return <ForgotPassword />;
      case AUTH_PAGE.RESET_PASSWORD:
        return <ResetPassword />;
      case AUTH_PAGE.ALERT:
        return <Alert />;
      default:
        return <Login />;
    }
  };

  return (
    <>
      <Modal visible={modal} transparent maskClosable={false} onClose={onCloseModal} className="width-250">
        <ModalAuth />
      </Modal>
    </>
  );
};

const mapStateToProps = (state: any) => ({
  isModalOpen: state.modalReducer.isModalOpen,
  page: state.modalReducer.page,
});

export default connect(mapStateToProps, null)(ModalPopup);
