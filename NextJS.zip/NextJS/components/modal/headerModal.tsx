import React from 'react';
import Image from 'next/image';
import LogoSvg from 'assets/images/icons/Logo.svg';

type HeaderModalType = {
  title: string;
  subtitle?: string;
  titleStyle?: string;
};

const HeaderModal = (props: HeaderModalType) => {
  return (
    <div className="d-flex flex-column justify-content-center align-items-center">
      <Image src={LogoSvg} width="40" height="40" alt="Logo" />
      <h1 className={`font-size-20 text-bold font-size-20 modal-title ${props.titleStyle || ''}`}>{props.title}</h1>
      {props.subtitle && <p className="font-size-9 line-height-15 text-normal width-190 mg-b-10">{props.subtitle}</p>}
    </div>
  );
};

export default HeaderModal;
