import React, { useEffect, useState } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { resentVerifyEmailRegister } from 'redux/actions';
import { authTypeConstants } from 'redux/constants';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

const VerifyRegister = (props: any) => {
  const [t] = useTranslation('verify_email');
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [type, setType] = useState(authTypeConstants.APPLICANT);

  useEffect(() => {
    setType(props.role);
    setEmail(props.email);
  }, [props.email, props.role]);

  const onSendVerifyEmailRegister = () => {
    const params = { email, type };
    dispatch(resentVerifyEmailRegister({ params }));
  };

  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('title')} />
        <React.Fragment>
          <div className="font-size-9 line-height-9 text-normal mg-b-0">{t('link_expired')}</div>
          <div className="header-modal-subtitle line-height-9 font-size-9 mg-b-20">{t('submit_new_request')}</div>
          <Button
            color="primary"
            type="submit"
            className="verify-register-btn modal-btn width-190 background-primary"
            onClick={onSendVerifyEmailRegister}
          >
            {t('btn_reset_link')}
          </Button>
          {props.error.isError && (
            <div className="text-danger width-per-100 font-size-9">{t(`error_message:${props.error.errorCode}`)}</div>
          )}
        </React.Fragment>
      </div>
      <FooterModal />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  email: state.verifyEmailReducer.user?.params?.email,
  role: state.verifyEmailReducer.user?.params?.role,
  error: state.verifyEmailReducer.error,
});

export default connect(mapStateToProps, null)(VerifyRegister);
