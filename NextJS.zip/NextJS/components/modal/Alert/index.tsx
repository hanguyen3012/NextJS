import React, { useEffect, useState } from 'react';
import { connect, useDispatch } from 'react-redux';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { resentVerifyEmailRegister } from 'redux/actions';
import { authTypeConstants } from 'redux/constants';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

const Alert = () => {
  const [t] = useTranslation('auth');

  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('check_email')} />
        <div className="font-size-9 line-height-9 text-normal mg-b-0 mg-t-20">{t('check_email_message')}</div>
        <div className="header-modal-subtitle line-height-9 font-size-9 mg-b-20">{t('check_if_not_receive')}</div>
      </div>
      <FooterModal />
    </>
  );
};

export default Alert;
