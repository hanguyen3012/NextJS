import React from 'react';
import { useForm } from 'react-hook-form';
import { FormInput } from 'components/form';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { connect, useDispatch } from 'react-redux';
import { forgotPassword } from 'redux/actions/authActions';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

interface IFormInputs {
  email: string;
}

const ForgotPassword = (props: any) => {
  const [t] = useTranslation();
  const { error } = props;
  const dispatch = useDispatch();

  const schema = yup.object().shape({
    email: yup.string().email(t('auth:email_is_required')).required(t('auth:password_is_required')),
  });
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInputs>({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data: IFormInputs) => {
    dispatch(forgotPassword({ params: data }));
  };

  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('forgot_password:title')} titleStyle="forgot-password-title" />
        <div className="header-modal-subtitle font-size-9" style={{ lineHeight: '9px' }}>
          {t('forgot_password:sub_title')}
        </div>
        <div
          className="header-modal-subtitle font-size-9 forgot-password-subtitle"
          style={{ whiteSpace: 'break-spaces', lineHeight: '9px' }}
        >
          {t('forgot_password:label_detail')}
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column justify-content-center align-items-center">
          <FormInput
            control={control}
            name="email"
            type="email"
            className={`form-control width-190 modal-input-field ${errors?.email ? 'mg-b-0' : 'forgot-password-input-field'}`}
            placeholder={t('forgot_password:placeholder_email')}
            errors={errors}
          />
          <Button color="primary" type="submit" className="width-190 modal-btn background-primary">
            {t('forgot_password:btn_forgot_password')}
          </Button>
          {error.isError && (
            <div className="text-danger width-190 mg-t-5 form-error text-left">{t(`error_message:${error?.errorCode}`)}</div>
          )}
        </form>
      </div>
      <FooterModal />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  error: state.authReducer?.error,
});

export default connect(mapStateToProps, null)(ForgotPassword);
