import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { connect, useDispatch } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

import { FormInput } from 'components/form';
import { verifyEmail } from 'redux/constants/verifyEmail';
import { REGEX } from 'shared/constant/common';
import { FAILURE, SUCCESS } from 'redux/constants';
import { resentVerifyEmailResetPassword, resetPassword } from 'redux/actions';
import FooterModal from '../footerModal';
import HeaderModal from '../headerModal';

interface IFormInputs {
  password: string;
  rePassword: string;
}

const ResetPassword = (props: any) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const [type, setType] = useState('');
  const [email, setEmail] = useState('');
  const { error } = props;

  useEffect(() => {
    setType(props.type);
    setEmail(props.email);
  }, [props.type, props.email]);

  const schema = yup.object().shape({
    password: yup
      .string()
      .required(t('auth:password_is_required'))
      .min(8, t('auth:password_length'))
      .max(22, t('auth:password_length'))
      .matches(REGEX.PASSWORD, t('auth:password_matches')),
    rePassword: yup
      .string()
      .required(t('auth:password_is_required'))
      .min(8, t('auth:password_length'))
      .max(22, t('auth:password_length'))
      .oneOf([yup.ref('password'), null], t('auth:password_must_match'))
      .matches(REGEX.PASSWORD, t('auth:password_matches')),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInputs>({
    resolver: yupResolver(schema),
  });

  const resentResetPasswordEmail = () => {
    const params = { email };
    dispatch(resentVerifyEmailResetPassword({ params }));
  };

  const onSubmit = (data: IFormInputs) => {
    const registerData = {
      password: data.password,
      password_confirmation: data.rePassword,
      token: props.token,
      email: props.email,
    };
    dispatch(resetPassword({ params: registerData }));
  };

  return (
    <>
      {(type === FAILURE(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD) || type === verifyEmail.RESENT_VERIFY_EMAIL_RESET_PASSWORD) && (
        <React.Fragment>
          <div className="modal-height">
            <HeaderModal title={t('reset_password:title')} />
            <div className="header-modal-subtitle font-size-9 mg-b-0">{t('reset_password:link_expired')}</div>
            <div className="header-modal-subtitle font-size-9 mg-b-20">{t('reset_password:submit_new_request')}</div>
            <Button
              onClick={resentResetPasswordEmail}
              color="primary"
              type="submit"
              className="reset-password-btn-reset width-190 font-size-10 background-primary"
            >
              {t('reset_password:btn_reset_link')}
            </Button>
          </div>
          <FooterModal />
        </React.Fragment>
      )}
      {type === SUCCESS(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD) && (
        <React.Fragment>
          <div className="modal-height-reset-password">
            <HeaderModal title={t('reset_password:title')} />
            <div className="font-size-9 text-normal" style={{ whiteSpace: 'break-spaces', marginBottom: '16px' }}>
              <span style={{ lineHeight: '9px' }}>{t('reset_password:sub_title')}</span>
              <span className="modal-reset-password-username" style={{ lineHeight: '9px' }}>
                &nbsp;{email}
              </span>
              <span style={{ lineHeight: '9px' }}>{t('reset_password:sub_title_detail')}</span>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column justify-content-center align-items-center">
              <FormInput
                control={control}
                name="password"
                type="password"
                className={`form-control width-190 height-28 font-size-8 ${errors?.password ? 'mg-b-0' : 'reset-password-input-field'}`}
                placeholder={t('reset_password:placeholder_password')}
                errors={errors}
              />
              <FormInput
                control={control}
                name="rePassword"
                type="password"
                className={`form-control width-190 height-28 font-size-8 ${errors?.rePassword ? 'mg-b-0' : 'mg-b-15'}`}
                placeholder={t('reset_password:placeholder_password_confirm')}
                errors={errors}
              />
              <Button
                color="primary"
                type="submit"
                className="reset-password-btn height-25 font-size-10 line-height-24 pd-0 background-primary"
              >
                {t('reset_password:btn_reset_password')}
              </Button>
              {error.isError && (
                <div className="text-danger width-190 mg-t-5 form-error text-left">{t(`error_message:${error?.errorCode}`)}</div>
              )}
            </form>
          </div>
        </React.Fragment>
      )}
    </>
  );
};
const mapStateToProps = (state: any) => ({
  type: state.verifyEmailReducer.status,
  email: state.verifyEmailReducer.user?.params?.email,
  role: state.verifyEmailReducer.user?.params?.role,
  token: state.verifyEmailReducer.user?.params?.token,
  error: state.authReducer?.error,
});

export default connect(mapStateToProps, null)(ResetPassword);
