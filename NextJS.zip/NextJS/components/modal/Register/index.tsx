import React, { useState } from 'react';
import { connect, useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
import { FormInput } from 'components/form';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { USER_TYPE } from 'shared/constant/common';
import { resentVerifyEmailRegister } from 'redux/actions';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

interface IFormInputs {
  email: string;
}

const Register = (props: any) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const [type, setType] = useState(USER_TYPE.APPLICANT);
  const schema = yup.object().shape({
    email: yup.string().email(t('auth:email_is_required')).required(t('auth:password_is_required')),
  });
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInputs>({
    resolver: yupResolver(schema),
  });
  const onSubmit = (data: IFormInputs) => {
    const params = {
      email: data.email,
      type,
    };
    dispatch(resentVerifyEmailRegister({ params }));
  };
  const changeType = (userType: string) => {
    if (userType === USER_TYPE.SALON) {
      setType(USER_TYPE.APPLICANT);
    } else {
      setType(USER_TYPE.SALON);
    }
  };
  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('auth:welcome')} subtitle={t('auth:please_enter_your_mail')} />
        <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column justify-content-center align-items-center">
          <FormInput
            control={control}
            name="email"
            type="email"
            className={`form-control width-190 height-30 font-size-8 text-normal ${errors?.email ? 'mg-b-0' : 'mg-b-15'}`}
            placeholder={t('auth:email')}
            errors={errors}
          />
          <Button color="primary" type="submit" className="width-190 height-25 pd-0 font-size-10 background-primary">
            {t('auth:sign_me_up')}
          </Button>
          {props.error.isError && (
            <div className="text-danger width-per-100 font-size-9">{t(`error_message:${props.error.errorCode}`)}</div>
          )}
        </form>
      </div>
      <FooterModal type={type} changeType={changeType} />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  error: state.verifyEmailReducer.error,
});

export default connect(mapStateToProps, null)(Register);
