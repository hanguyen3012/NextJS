import React from 'react';
import { useForm } from 'react-hook-form';
import { FormInput } from 'components/form';
import { Button } from 'reactstrap';
import { connect, useDispatch } from 'react-redux';
import { useTranslation } from 'i18next-config';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { loginUser } from 'redux/actions/authActions';
import { openModal } from 'redux/actions';
import { AUTH_PAGE } from 'shared/constant/common';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

interface IFormInputs {
  email: string;
  password: string;
}

const Login = (props: any) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();

  const { error } = props;

  const schema = yup.object().shape({
    email: yup.string().email(t('auth:email_is_required')).required(t('auth:password_is_required')),
    password: yup.string().required(t('auth:password_is_required')),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInputs>({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data: IFormInputs) => {
    dispatch(loginUser({ params: data, pagination: { page: AUTH_PAGE.LOGIN } }));
  };

  const showPopupForgotPassword = () => {
    dispatch(openModal(AUTH_PAGE.FORGOT_PASSWORD));
  };

  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('auth:welcome_back')} titleStyle="mg-b-30" />
        <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column justify-content-center align-items-center">
          <FormInput
            control={control}
            name="email"
            type="email"
            className={`form-control width-190 height-30 font-size-8 text-normal ${errors?.email ? 'mg-b-0' : 'mg-b-15'}`}
            placeholder={t('auth:email')}
            errors={errors}
          />
          <FormInput
            control={control}
            name="password"
            type="password"
            className="form-control mg-b-0 width-190 height-30 font-size-8 text-normal"
            placeholder={t('auth:password')}
            errors={errors}
          />
          <p className="align-self-end font-size-8 mg-r-20 text-normal mg-b-0 color-primary" onClick={showPopupForgotPassword}>
            {t('auth:forgot_password')}
          </p>
          <Button color="primary" type="submit" className="width-75 height-25 pd-0 font-size-10 background-primary">
            {t('auth:sign_in')}
          </Button>
          {error.isError && <div className="text-danger width-per-100 font-size-9">{t(`error_message:${error?.errorCode}`)}</div>}
        </form>
      </div>
      <FooterModal isRegister={true} />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  error: state.authReducer.error,
});

export default connect(mapStateToProps, null)(Login);
