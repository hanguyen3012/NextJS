import React from 'react';
import { connect, useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
import { FormInput } from 'components/form';
import { Button } from 'reactstrap';
import { useTranslation } from 'i18next-config';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { register } from 'redux/actions/authActions';
import { AUTH_PAGE, REGEX } from 'shared/constant/common';
import HeaderModal from '../headerModal';
import FooterModal from '../footerModal';

interface IFormInputs {
  password: string;
  rePassword: string;
}

const RegisterPassword = (props: any) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const schema = yup.object().shape({
    password: yup
      .string()
      .required(t('auth:password_is_required'))
      .min(8, t('auth:password_length'))
      .max(22, t('auth:password_length'))
      .matches(REGEX.PASSWORD, t('auth:password_matches')),
    rePassword: yup
      .string()
      .required(t('auth:password_is_required'))
      .min(8, t('auth:password_length'))
      .max(22, t('auth:password_length'))
      .oneOf([yup.ref('password'), null], t('auth:password_must_match'))
      .matches(REGEX.PASSWORD, t('auth:password_matches')),
  });
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInputs>({
    resolver: yupResolver(schema),
  });
  const onSubmit = (data: IFormInputs) => {
    const registerData = {
      password: data.password,
      password_confirmation: data.rePassword,
      token: props.user?.params?.token,
      email: props.user?.params?.email,
    };
    dispatch(register({ params: registerData, pagination: { page: AUTH_PAGE.REGISTER } }));
  };

  return (
    <>
      <div className="modal-height">
        <HeaderModal title={t('auth:almost_there')} subtitle={t('auth:your_email_has_been_verified')} />
        <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column justify-content-center align-items-center">
          <FormInput
            control={control}
            name="password"
            type="password"
            className={`form-control width-190 height-30 font-size-8 text-normal ${errors?.password ? 'mg-b-0' : 'mg-b-10'}`}
            placeholder={t('auth:enter_password')}
            errors={errors}
          />
          <FormInput
            control={control}
            name="rePassword"
            type="password"
            className={`form-control width-190 height-30 font-size-8 text-normal ${errors?.rePassword ? 'mg-b-0' : 'mg-b-10'}`}
            placeholder={t('auth:enter_password_again')}
            errors={errors}
          />
          <Button color="primary" type="submit" className="width-190 height-25 pd-0 font-size-10 background-primary">
            {t('auth:sign_in')}
          </Button>
        </form>
      </div>
      <FooterModal />
    </>
  );
};

const mapStateToProps = (state: any) => ({
  user: state.verifyEmailReducer.user,
});

export default connect(mapStateToProps, null)(RegisterPassword);
