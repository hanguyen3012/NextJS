import React, { useState, useEffect } from 'react';
import { connect, ConnectedProps } from 'react-redux';
import { compose } from 'redux';
import Link from 'next/link';
import { Container, Dropdown, DropdownMenu, DropdownToggle, Button } from 'reactstrap';
// import { UilSignOutAlt } from '@iconscout/react-unicons';
import { User, Menu } from 'react-feather';
import logo from 'assets/images/logo.png';
import { logout } from 'redux/actions/authActions';
import { setMenuStateCollapse, setMenuStateExpanded } from 'redux/actions/menuActions';

interface ITopbarProps extends PropsFromRedux {
  logoutAction: (params?: any) => any;
}
const Topbar = (props: ITopbarProps) => {
  const { currentUser, logoutAction, menuExpanded, setMenuExpanded, setMenuCollapse } = props;
  console.log(currentUser);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleResize = () => {
    const width = window.innerWidth;

    if (width <= 767) {
      setMenuCollapse();
    }
  };

  useEffect(() => {
    handleResize();
    window.addEventListener('resize', () => {
      handleResize();
    });
  });

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleLogout = () => {
    // will check and handle more after have API.
    logoutAction(() => {
      // handle it
    });
  };

  const setMenuState = (e: any) => {
    e.preventDefault();
    if (!menuExpanded) {
      setMenuExpanded();
      return;
    }
    setMenuCollapse();
  };

  return (
    <React.Fragment>
      <div className="navbar navbar-expand flex-column flex-md-row navbar-custom">
        <Container fluid>
          <Button onClick={setMenuState} color="info" className="button-menu-mobile bg-color-transparent mr-0">
            <Menu className="menu-icon" />
          </Button>
          <Link href="/">
            <a className="navbar-brand mr-0 mr-md-2 logo">
              <span className="logo-lg d-flex align-items-center pt-1">
                <img src={logo} alt="" height="24" />
                <span className="h5 ml-2 text-logo pt-2p">NAL-Template</span>
              </span>
            </a>
          </Link>
          <ul className="navbar-nav flex-row ml-auto d-flex list-unstyled topnav-menu float-right mb-0">
            <li className="notification-list">
              <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
                <DropdownToggle
                  data-toggle="dropdown"
                  tag="a"
                  className="nav-link dropdown-toggle"
                  onClick={toggleDropdown}
                  aria-expanded={dropdownOpen}
                >
                  <User />
                </DropdownToggle>
                <DropdownMenu right className="dropdown-md profile-dropdown">
                  <div role="button" onClick={toggleDropdown}>
                    <div className="dropdown-item border-bottom">{currentUser && currentUser.name}</div>
                    <div className="dropdown-item" role="button" onClick={() => handleLogout()}>
                      <div className="d-flex align-items-center">
                        <span className="accounticon-logout" />
                        <span className="d-block pl-2 mt-3p line-height-1">Logout</span>
                      </div>
                    </div>
                  </div>
                </DropdownMenu>
              </Dropdown>
            </li>
          </ul>
        </Container>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = (state: any) => ({
  currentUser: state.authReducer.user,
  menuExpanded: state.menuReducer.isExpanded,
});

const mapDispatchToProps = (dispatch: any) => ({
  logoutAction: (params: any) => dispatch(logout(params)),
  setMenuExpanded: () => dispatch(setMenuStateExpanded()),
  setMenuCollapse: () => dispatch(setMenuStateCollapse()),
});

const withConnect = connect(mapStateToProps, mapDispatchToProps);
type PropsFromRedux = ConnectedProps<typeof withConnect>;

export default withConnect(Topbar);
