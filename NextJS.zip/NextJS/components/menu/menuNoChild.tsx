import React, { Fragment } from 'react';
import classNames from 'classnames';
import Link from 'next/link';
import { MenuChildProps } from 'types/menu';

const MenuNoChild = ({
  title,
  route,
  link,
  activePath,
  icon,
  customClass,
  customIconClass,
  customLinkClass,
  labelClass,
  activeRegex,
  user,
  query,
  as,
}: MenuChildProps) => {
  const userRoles = (user || {}).currentRoles || [];
  const Icon = icon;
  const isActivedItem = route.indexOf(activePath) >= 0 || (route === '/' && activePath === '/dashboard');

  const renderLinkItem = () => (
    <a
      className={classNames(customLinkClass || '', {
        active: activeRegex ? activeRegex.test(route) : isActivedItem,
      })}
    >
      <div className="menu-item">
        <div className="d-flex align-items-center height-by-px-24">
          {icon &&
            (activePath === '/user-management' ? (
              <span className="left-icon">
                <Icon className={`icon-xs ${customIconClass}`} style={{ fill: 'transparent' }} />
              </span>
            ) : (
              <span className="left-icon">
                <Icon className={`icon-xs ${customIconClass}`} />
              </span>
            ))}
          <span className={`${labelClass || ''} side-nav-text`}>{title}</span>
        </div>
      </div>
    </a>
  );

  return (
    <Fragment>
      <li
        className={classNames(customClass, {
          'mm-active': isActivedItem,
        })}
      >
        {link ? (
          <Link
            href={{
              pathname: link,
              query,
            }}
            as={as}
          >
            {renderLinkItem()}
          </Link>
        ) : (
          renderLinkItem()
        )}
      </li>
    </Fragment>
  );
};

export default MenuNoChild;
