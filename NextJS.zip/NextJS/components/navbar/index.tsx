import React from 'react';
import { NavBar, Button } from 'antd-mobile';
import Image from 'next/image';
import BellSvg from 'assets/images/icons/bell.svg';
import HomeSvg from 'assets/images/icons/home.svg';
import MenuSvg from 'assets/images/icons/menu.svg';
import ChatQuoteSvg from 'assets/images/icons/chatQuote.svg';
import CalendarSvg from 'assets/images/icons/calendar.svg';
import PersonSquareSvg from 'assets/images/icons/personSquare.svg';
import { openModal } from 'redux/actions';
import { AUTH_PAGE } from 'shared/constant/common';
import { useDispatch } from 'react-redux';

type NavType = {
  isAuth: boolean;
  isMobile: boolean;
};

function Nav(props: NavType) {
  const { isAuth, isMobile } = props;
  const dispatch = useDispatch();

  const openModalAuth = (type: string) => {
    if (type === AUTH_PAGE.LOGIN) {
      dispatch(openModal(AUTH_PAGE.LOGIN));
    } else if (type === AUTH_PAGE.SIGN_UP_EMAIL) {
      dispatch(openModal(AUTH_PAGE.SIGN_UP_EMAIL));
    }
  };

  if (isMobile) {
    if (isAuth) {
      return (
        <NavBar
          mode="light"
          leftContent={<div>logo</div>}
          rightContent={[
            <Image src={HomeSvg} key="0" alt="Home" width="25" height="25" />,
            <Image src={BellSvg} key="1" alt="Bell" width="25" height="25" />,
            <Image src={MenuSvg} key="2" alt="Menu" width="25" height="25" />,
          ]}
        />
      );
    }
    return (
      <NavBar
        mode="light"
        onLeftClick={() => console.log('onLeftClick')}
        leftContent={<div>logo</div>}
        rightContent={[
          <div key="0" style={{ marginRight: '16px', color: 'white' }}>
            <Button type="primary" size="small" onClick={() => openModalAuth(AUTH_PAGE.LOGIN)}>
              Login
            </Button>
          </div>,
          <div key="1" style={{ color: 'white' }}>
            <Button type="primary" size="small" onClick={() => openModalAuth(AUTH_PAGE.SIGN_UP_EMAIL)}>
              Register
            </Button>
          </div>,
        ]}
      />
    );
  }
  return (
    <>
      {isAuth ? (
        <NavBar
          mode="light"
          leftContent={<div>logo</div>}
          rightContent={[
            <div key="0" style={{ marginRight: '16px', color: 'white' }}>
              <Image src={HomeSvg} alt="Home" width="25" height="25" />,
            </div>,
            <div key="1" style={{ color: 'white', display: 'flex' }}>
              <Image src={ChatQuoteSvg} alt="Chat Quote" width="25" height="25" />
              <Image src={CalendarSvg} alt="Calendar" width="25" height="25" />
              <Image src={BellSvg} alt="Bell" width="25" height="25" />
              <Image src={PersonSquareSvg} alt="Person Square" width="25" height="25" />
            </div>,
          ]}
        />
      ) : (
        <NavBar
          mode="light"
          leftContent={<div>logo</div>}
          rightContent={[
            <div key="0" style={{ marginRight: '16px', color: 'white' }}>
              <Image src={HomeSvg} alt="Home" width="25" height="25" />
            </div>,
            <div key="1" style={{ color: 'white', display: 'flex' }}>
              <Button type="primary" size="small" style={{ marginRight: '16px' }} onClick={() => openModalAuth(AUTH_PAGE.LOGIN)}>
                Login
              </Button>
              <Button type="primary" size="small" onClick={() => openModalAuth(AUTH_PAGE.SIGN_UP_EMAIL)}>
                Register
              </Button>
            </div>,
          ]}
        />
      )}
    </>
  );
}

export default Nav;
