import React from 'react';
import { Controller } from 'react-hook-form';

import { InputTypes } from 'types';
import { FormError } from 'components/form/error';

interface InterfaceTextarea extends InputTypes {
  rows?: number;
}

const FormTextarea = ({ control, name, rows, className, placeholder, defaultValue, errors }: InterfaceTextarea) => (
  <div>
    <Controller
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <textarea
          className={className}
          rows={rows}
          placeholder={placeholder}
          {...field}
          value={field.value || ''}
          onChange={e => field.onChange(e.target.value)}
          onBlur={() => field.value && field.onChange(field.value.trim())}
        />
      )}
    />
    <FormError name={name} errors={errors} />
  </div>
);

export { FormTextarea };
