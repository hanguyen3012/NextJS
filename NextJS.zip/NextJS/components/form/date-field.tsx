import React, { useState } from 'react';
import { Controller } from 'react-hook-form';
import DatePicker, { ReactDatePickerProps } from 'react-datepicker';

import { InputTypes } from 'types';
import { FormError } from 'components/form/error';

interface InterfaceInput extends InputTypes, Omit<ReactDatePickerProps, 'onChange' | 'name'> {}

const FormDate = ({ control, name, defaultValue, errors, ...inputProps }: InterfaceInput) => (
  <div>
    <Controller
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field: { onChange, value } }) => <DatePicker {...inputProps} selected={value} onChange={date => onChange(date)} />}
    />
    <FormError name={name} errors={errors} />
  </div>
);

const DateRange = () => {
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  return (
    <div className="form-group form-group-date-range d-flex align-items-center">
      <div className="form-item width-130">
        <DatePicker
          id="DatePicker-start"
          className="form-control"
          selected={startDate}
          onChange={(date: any) => setStartDate(date)}
          selectsStart
          startDate={startDate}
          endDate={endDate}
        />
        <label className="form-item-icon" htmlFor="DatePicker-start">
          <i className="bi bi-calendar-week"></i>
        </label>
      </div>
      <div className="form-item mg-l-10 mg-r-10">〜</div>
      <div className="form-item width-130">
        <DatePicker
          id="DatePicker-end"
          className="form-control"
          selected={endDate}
          onChange={(date: any) => setEndDate(date)}
          selectsEnd
          startDate={startDate}
          endDate={endDate}
          minDate={startDate}
        />
        <label className="form-item-icon" htmlFor="DatePicker-end">
          <i className="bi bi-calendar-week"></i>
        </label>
      </div>
    </div>
  );
};

const DateRangeFromTo = () => {
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  return (
    <div className="form-group-date-from-to">
      <label className="form-item form-item-icon" htmlFor="DatePicker-start">
        <i className="bi bi-calendar-week"></i>
      </label>
      <div className="form-item width-130">
        <DatePicker
          id="DatePicker-start"
          className="form-control"
          selected={startDate}
          onChange={(date: any) => setStartDate(date)}
          selectsStart
          startDate={startDate}
          endDate={endDate}
        />
      </div>
      <div className="form-item">〜</div>
      <div className="form-item width-130">
        <DatePicker
          id="DatePicker-end"
          className="form-control"
          selected={endDate}
          onChange={(date: any) => setEndDate(date)}
          selectsEnd
          startDate={startDate}
          endDate={endDate}
          minDate={startDate}
        />
      </div>
    </div>
  );
};

export { DateRange, DateRangeFromTo, FormDate };
