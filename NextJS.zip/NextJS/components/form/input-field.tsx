import React, { useState, Fragment, useEffect } from 'react';
import { Controller } from 'react-hook-form';
import Image from 'next/image';

import { InputTypes } from 'types';
import { FormError } from 'components/form/error';
import EyeSvg from 'assets/images/icons/eye.svg';

interface InterfaceInput extends InputTypes {
  type: string;
  options?: any;
  onChange?: any;
}

interface InterfaceRadioGroup extends Omit<InputTypes, 'control'> {
  control?: any;
  options?: any;
  value: any;
  onChange: any;
}

const FormRadioGroup = (props: InterfaceRadioGroup) => {
  const { name, options = [], onChange, value } = props;

  return (
    <Fragment>
      {options.map((item: any, key: any) => (
        <div key={key} className="custom-control custom-radio radio-inline">
          <input
            id={`${name}-${key}`}
            name={name}
            className="form-check-input custom-control-input"
            type="radio"
            onChange={() => onChange(item.value)}
            checked={item.value === value}
            value={item.value}
          />
          <label className="custom-control-label mb-0" htmlFor={`${name}-${key}`}>
            {item.label}
          </label>
        </div>
      ))}
    </Fragment>
  );
};

const FormCheckboxGroup = (props: InterfaceRadioGroup) => {
  const { name, options = [], onChange, value = [] } = props;
  const handleChange = (checked: boolean, v: any) => {
    let newValue: any = [...value];
    if (checked) {
      newValue.push(v);
    } else {
      newValue = newValue.filter((item: any) => item !== v);
    }
    onChange(newValue);
  };

  return (
    <Fragment>
      {options.map((item: any, key: any) => (
        <div key={key} className="custom-control custom-radio radio-inline">
          <input
            id={`${name}-${key}`}
            name={name}
            type="checkbox"
            className="form-check-input custom-control-input"
            onChange={e => handleChange(e.target.checked, e.target.value)}
            value={item.value}
          />
          <label className="custom-control-label mb-0" htmlFor={`${name}-${key}`}>
            {item.label}
          </label>
        </div>
      ))}
    </Fragment>
  );
};

const FormInput = ({ control, name, type, errors = {}, options, ...inputProps }: InterfaceInput) => {
  const [isType, setIsType] = useState('');

  useEffect(() => {
    if (type === 'password') {
      setIsType(type);
    }
  }, [type]);

  const onClickType = () => {
    if (isType === 'password') {
      setIsType('text');
    } else {
      setIsType('password');
    }
  };

  return (
    <div>
      <Controller
        control={control}
        name={name}
        render={({ field: { onChange, value } }) => {
          if (type === 'radio_group') {
            return <FormRadioGroup name={name} options={options} value={value} onChange={onChange} />;
          }
          if (type === 'checkbox_group') {
            return (
              <FormCheckboxGroup
                name={name}
                control={control}
                options={options}
                value={value}
                onChange={(data: any) => {
                  onChange(data);
                }}
              />
            );
          }
          if (type === 'password') {
            return (
              <div className="form-password">
                <input
                  type={isType}
                  {...inputProps}
                  value={value || ''}
                  onChange={e => onChange(e.target.value)}
                  onBlur={() => typeof value === 'string' && onChange(value.trim())}
                />
                <div className="form-icon">
                  <Image src={EyeSvg} width="10" height="10" alt="eyeIcon" onClick={onClickType} />
                </div>
              </div>
            );
          }
          return (
            <input
              type={type}
              {...inputProps}
              value={value || ''}
              onChange={e => onChange(e.target.value)}
              onBlur={() => typeof value === 'string' && onChange(value.trim())}
            />
          );
        }}
      />
      <FormError name={name} errors={errors} />
    </div>
  );
};

export { FormInput };
