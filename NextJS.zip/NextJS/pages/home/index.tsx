import React, { useEffect, useState } from 'react';
import Router from 'next/router';
import { useDispatch } from 'react-redux';

import { verifyEmailRegister, verifyEmailResetPassword } from 'redux/actions';
import { AUTH_PAGE, ROUTER } from 'shared/constant/common';
import { paramUrlVerifyEmail, typeApiVerifyEmail } from 'redux/constants/verifyEmail';
import { getParamsFromUrl } from 'shared/utils';

const Home = () => {
  const dispatch = useDispatch();
  const [type, setType] = useState('');
  const [activeEmail, setActiveEmail] = useState({ email: '', token: '', role: '' });

  // mock data
  const checkVerifyEmail = () => {
    if (type === typeApiVerifyEmail.REGISTER) {
      const params = { email: activeEmail.email, token: activeEmail.token, role: activeEmail.role };
      dispatch(verifyEmailRegister({ params }));
      Router.push(ROUTER.Home);
    } else if (type === typeApiVerifyEmail.RESET_PASSWORD) {
      const params = { email: activeEmail.email, token: activeEmail.token, role: activeEmail.role };
      dispatch(verifyEmailResetPassword({ params }));
      Router.push(ROUTER.Home);
    }
  };

  useEffect(() => {
    if (!type) {
      const currentUrl = window.location.href;
      const typeFromUrl = getParamsFromUrl(paramUrlVerifyEmail.TYPE, currentUrl);
      const emailFromUrl = getParamsFromUrl(paramUrlVerifyEmail.EMAIL, currentUrl);
      const tokenFromUrl = getParamsFromUrl(paramUrlVerifyEmail.TOKEN, currentUrl);
      const roleFromUrl = getParamsFromUrl(paramUrlVerifyEmail.ROLE, currentUrl);
      if (typeFromUrl) {
        setType(typeFromUrl);
        if (emailFromUrl && tokenFromUrl && roleFromUrl) {
          setActiveEmail({ email: emailFromUrl, token: tokenFromUrl, role: roleFromUrl });
        }
      }
    }
  }, []);

  useEffect((): void => {
    checkVerifyEmail();
  }, [type]);

  return <></>;
};

export default Home;
