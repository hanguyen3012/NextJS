import React, { Fragment, useEffect } from 'react';
import '../assets/scss/theme.scss';
import 'antd-mobile/dist/antd-mobile.css';

import { AppProps } from 'next/app';
import { connect } from 'react-redux';
import { wrapper } from 'redux/store';
import AuthLayout from 'components/layout/auth';
import MainLayout from 'components/layout/mainLayout';
import { appWithTranslation } from 'i18next-config';
import Modal from 'components/modal';
import Head from 'next/head';

// eslint-disable-next-line react/react-in-jsx-scope
const MyApp = ({ Component, pageProps }: AppProps) => {
  const Layout = pageProps.isLayoutAuth === true ? AuthLayout : MainLayout;
  return (
    <Fragment>
      <Layout>
        <Modal />
        <Component {...pageProps} />
      </Layout>
      <Head>
      </Head>
    </Fragment>
  );
};

const mapDispatchToProps = () => ({});

const withConnect = connect(null, mapDispatchToProps);

export default wrapper.withRedux(withConnect(appWithTranslation(MyApp)));
