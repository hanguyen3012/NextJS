export const { API_URL } = process.env;
export const { SENTRY_DSN } = process.env;
export const { APP_ENV } = process.env;
export const { BASIC_ENV, BASIC_USERNAME, BASIC_PASSWORD } = process.env;
