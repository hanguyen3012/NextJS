import { useState, useEffect } from 'react';
import { SIZE_DEVICE } from '../constant/common';

interface size {
  width: number;
}

function useWindowSize() {
  const [widthSize, setWidthSize] = useState<size>({
    width: 0,
  });

  useEffect(() => {
    function handleResize() {
      setWidthSize({
        width: window.innerWidth,
      });
    }
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  return widthSize;
}

function useDevice(name: string) {
  const [isDevice, setIsDevice] = useState<boolean>(false);
  const widthSize = useWindowSize();

  useEffect(() => {
    switch (name) {
      case 'mobile': {
        const checkIsMobile = widthSize.width <= SIZE_DEVICE.SIZE_MOBILE;
        setIsDevice(checkIsMobile);
        break;
      }
      default: {
        const checkIsDesktop = widthSize.width > SIZE_DEVICE.SIZE_MOBILE;
        setIsDevice(checkIsDesktop);
      }
    }
  }, [widthSize.width, name]);

  return isDevice;
}

export { useWindowSize, useDevice };
