declare module 'i18n';
