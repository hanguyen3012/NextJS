declare module '@iconscout';
