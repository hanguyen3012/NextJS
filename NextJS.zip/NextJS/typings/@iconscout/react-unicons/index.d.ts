declare module '@iconscout/react-unicons';
