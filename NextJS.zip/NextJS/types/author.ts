type Author = {
  name: string;
  picture: string;
};

export type { Author };
