import { put, all, takeEvery, call } from 'redux-saga/effects';

import { Action, ResponseGenerator } from 'types/action';
import Api from 'shared/config/api';
import { URL_FORGOT_PASSWORD, URL_LOGIN, URL_RESENT_VERIFY_EMAIL_REGISTER, URL_RESET_PASSWORD } from 'shared/constant/endpoints';
import { AUTH_PAGE } from 'shared/constant/common';
import { CookiesStorage } from 'shared/config/cookie';
import { closeModal } from 'redux/actions/modalActions';
import { REQUEST, SUCCESS, FAILURE, modalConstants, authConstants } from '../constants';

function* loginAuthenManual(action: Action) {
  const { params, pagination } = action.payload || {};
  const AuthApi = pagination.page === AUTH_PAGE.LOGIN ? Api.post(URL_LOGIN, params) : Api.put(URL_RESENT_VERIFY_EMAIL_REGISTER, params);

  try {
    const response: ResponseGenerator = yield call(() => AuthApi);
    if (response?.status === 200) {
      CookiesStorage.setAccessToken(response.data.data.accessToken);
      yield put(closeModal());
      yield put({
        type: SUCCESS(authConstants.LOGIN),
        payload: {
          response: {
            accessToken: response.data.data.accessToken,
            tokenType: response.data.data.tokenType,
            account: response.data.data.account,
          },
        },
      });
    }
  } catch (error: any) {
    yield put({
      type: FAILURE(authConstants.LOGIN),
      payload: {
        response: {
          statusCode: error.data.error.status_code,
          code: error.data.error.code,
          message: error.data.error.message,
          errorCode: error.data.error.error_code,
          errors: error.data.error.errors,
        },
      },
    });
  }
}

function* forgotPassword(action: Action) {
  const { params } = action.payload || {};
  const resentVerifyUrl = Api.post(URL_FORGOT_PASSWORD, params);
  try {
    const response: ResponseGenerator = yield call(() => resentVerifyUrl);
    if (response?.status === 200) {
      yield all([
        put({
          type: SUCCESS(authConstants.FORGOT_PASSWORD),
        }),
        put({
          type: modalConstants.CLOSE,
        }),
      ]);
    }
  } catch (error: any) {
    yield put({
      type: FAILURE(authConstants.FORGOT_PASSWORD),
      payload: {
        response: {
          statusCode: error.data.error.status_code,
          code: error.data.error.code,
          message: error.data.error.message,
          errorCode: error.data.error.error_code,
          errors: error.data.error.errors,
        },
      },
    });
  }
}

function* resetPassword(action: Action) {
  const { params } = action.payload || {};
  const resentVerifyUrl = Api.put(URL_RESET_PASSWORD, params);
  try {
    const response: ResponseGenerator = yield call(() => resentVerifyUrl);
    if (response?.status === 200) {
      yield all([
        put({
          type: SUCCESS(authConstants.RESET_PASSWORD),
        }),
        put({
          type: modalConstants.CLOSE,
        }),
      ]);
    }
  } catch (error: any) {
    yield put({
      type: FAILURE(authConstants.RESET_PASSWORD),
      payload: {
        response: {
          statusCode: error.data.error.status_code,
          code: error.data.error.code,
          message: error.data.error.message,
          errorCode: error.data.error.error_code,
          errors: error.data.error.errors,
        },
      },
    });
  }
}

function* authSaga() {
  yield all([
    takeEvery(REQUEST(authConstants.LOGIN), loginAuthenManual),
    takeEvery(authConstants.REGISTER, loginAuthenManual),
    takeEvery(REQUEST(authConstants.FORGOT_PASSWORD), forgotPassword),
    takeEvery(REQUEST(authConstants.RESET_PASSWORD), resetPassword),
  ]);
}

export default authSaga;
