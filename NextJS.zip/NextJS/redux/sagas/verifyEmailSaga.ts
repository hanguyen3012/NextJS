import { put, all, call, takeEvery } from 'redux-saga/effects';
import { verifyEmail } from 'redux/constants/verifyEmail';
import Api from 'shared/config/api';
import { AUTH_PAGE } from 'shared/constant/common';
import {
  URL_FORGOT_PASSWORD,
  URL_RESENT_VERIFY_EMAIL_REGISTER,
  URL_VERIFY_EMAIL_REGISTER,
  URL_VERIFY_EMAIL_RESET_PASSWORD,
} from 'shared/constant/endpoints';

import { Action, ResponseGenerator } from 'types/action';
import { SUCCESS, FAILURE, modalConstants } from '../constants';

function* verifyRegisterEmail(action: Action) {
  const { params } = action.payload || {};
  const dataVerify = { email: params.email, token: params.token };
  const verifyUrl = Api.get(URL_VERIFY_EMAIL_REGISTER, {
    params: dataVerify,
  });
  try {
    const response: ResponseGenerator = yield call(() => verifyUrl);
    if (response) {
      yield all([
        put({
          type: SUCCESS(verifyEmail.VERIFY_EMAIL_REGISTER),
          error: {},
        }),
        put({
          type: modalConstants.OPEN,
          payload: AUTH_PAGE.SIGN_UP_PASSWORD,
        }),
      ]);
    }
  } catch (error) {
    yield all([
      put({
        type: FAILURE(verifyEmail.VERIFY_EMAIL_REGISTER),
        payload: {
          response: {
            statusCode: error.data.error.status_code,
            code: error.data.error.code,
            message: error.data.error.message,
            errorCode: error.data.error.error_code,
            errors: error.data.error.errors,
          },
        },
      }),
      put({
        type: modalConstants.OPEN,
        payload: AUTH_PAGE.VERIFY_EMAIL_REGISTER,
      }),
    ]);
  }
}

function* resentVerifyRegisterEmail(action: Action) {
  const { params } = action.payload || {};
  const resentVerifyUrl = Api.post(URL_RESENT_VERIFY_EMAIL_REGISTER, params);
  try {
    const response: ResponseGenerator = yield call(() => resentVerifyUrl);
    if (response) {
      yield all([
        put({
          type: SUCCESS(verifyEmail.VERIFY_EMAIL_REGISTER),
        }),
        put({
          type: modalConstants.OPEN,
          payload: AUTH_PAGE.ALERT,
        }),
      ]);
    }
  } catch (error) {
    yield put({
      type: FAILURE(verifyEmail.VERIFY_EMAIL_REGISTER),
      payload: {
        response: {
          statusCode: error.data.error.status_code,
          code: error.data.error.code,
          message: error.data.error.message,
          errorCode: error.data.error.error_code,
          errors: error.data.error.errors,
        },
      },
    });
  }
}

function* verifyResetPasswordEmail(action: Action) {
  const { params } = action.payload || {};
  const dataVerify = { email: params.email, token: params.token };
  const verifyUrl = Api.get(URL_VERIFY_EMAIL_RESET_PASSWORD, {
    params: dataVerify,
  });
  try {
    const response: ResponseGenerator = yield call(() => verifyUrl);
    if (response) {
      yield all([
        put({
          type: SUCCESS(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD),
          error: {},
        }),
        put({
          type: modalConstants.OPEN,
          payload: AUTH_PAGE.RESET_PASSWORD,
        }),
      ]);
    }
  } catch (error) {
    yield all([
      put({
        type: FAILURE(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD),
        payload: {
          response: {
            statusCode: error.data.error.status_code,
            code: error.data.error.code,
            message: error.data.error.message,
            errorCode: error.data.error.error_code,
            errors: error.data.error.errors,
          },
        },
      }),
      put({
        type: modalConstants.OPEN,
        payload: AUTH_PAGE.RESET_PASSWORD,
      }),
    ]);
  }
}

function* resentResetPasswordEmail(action: Action) {
  const { params } = action.payload || {};
  const resentVerifyUrl = Api.post(URL_FORGOT_PASSWORD, params);
  try {
    const response: ResponseGenerator = yield call(() => resentVerifyUrl);
    if (response) {
      yield all([
        put({
          type: SUCCESS(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD),
        }),
        put({
          type: modalConstants.OPEN,
          payload: AUTH_PAGE.ALERT,
        }),
      ]);
    }
  } catch (error) {
    yield put({
      type: FAILURE(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD),
      payload: {
        response: {
          statusCode: error.data.error.status_code,
          code: error.data.error.code,
          message: error.data.error.message,
          errorCode: error.data.error.error_code,
          errors: error.data.error.errors,
        },
      },
    });
  }
}

function* authVerifyEmailRegisterSaga() {
  yield all([
    takeEvery(verifyEmail.VERIFY_EMAIL_REGISTER, verifyRegisterEmail),
    takeEvery(verifyEmail.RESENT_VERIFY_EMAIL_REGISTER, resentVerifyRegisterEmail),
    takeEvery(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD, verifyResetPasswordEmail),
    takeEvery(verifyEmail.RESENT_VERIFY_EMAIL_RESET_PASSWORD, resentResetPasswordEmail),
  ]);
}

export default authVerifyEmailRegisterSaga;
