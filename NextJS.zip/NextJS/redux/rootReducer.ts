import { combineReducers } from 'redux';
import authReducer from './reducers/authReducer';
import menuReducer from './reducers/menuReducer';
import modalReducer from './reducers/modalReducers';
import verifyEmailReducer from './reducers/verifyReducer';

export default combineReducers({
  authReducer,
  menuReducer,
  modalReducer,
  verifyEmailReducer,
});
