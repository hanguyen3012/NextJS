export const verifyEmail = {
  VERIFY_EMAIL_REGISTER: 'VERIFY_EMAIL_REGISTER',
  RESENT_VERIFY_EMAIL_REGISTER: 'RESENT_VERIFY_EMAIL_REGISTER',
  VERIFY_EMAIL_RESET_PASSWORD: 'VERIFY_EMAIL_RESET_PASSWORD',
  RESENT_VERIFY_EMAIL_RESET_PASSWORD: 'RESENT_VERIFY_EMAIL_RESET_PASSWORD',
};

export const typeApiVerifyEmail = {
  REGISTER: 'register',
  RESET_PASSWORD: 'reset-password',
};

export const paramUrlVerifyEmail = {
  TYPE: 'type',
  EMAIL: 'email',
  TOKEN: 'token',
  ROLE: 'role',
};
