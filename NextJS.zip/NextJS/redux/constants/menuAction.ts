export const menuState = {
  EXPANDED: 'EXPANDED',
  COLLAPSE: 'COLLAPSE',
};
