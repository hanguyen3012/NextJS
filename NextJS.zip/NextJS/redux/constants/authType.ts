export const authTypeConstants = {
  SALON: 'salon',
  APPLICANT: 'applicant',
};
