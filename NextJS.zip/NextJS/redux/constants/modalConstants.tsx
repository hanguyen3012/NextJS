export const modalConstants = {
  OPEN: 'OPEN',
  CLOSE: 'CLOSE',
};
