import { Payload } from 'types/action';
import { REQUEST, authConstants } from '../constants';

export const loginUser = (payload: Payload) => ({
  type: REQUEST(authConstants.LOGIN),
  payload,
});

export const logout = (callback: any) => ({
  type: REQUEST(authConstants.LOGOUT),
  callback,
});

export const register = (payload: Payload) => ({
  type: authConstants.REGISTER,
  payload,
});

export const forgotPassword = (payload: Payload) => ({
  type: REQUEST(authConstants.FORGOT_PASSWORD),
  payload,
});

export const resetPassword = (payload: Payload) => ({
  type: REQUEST(authConstants.RESET_PASSWORD),
  payload,
});
