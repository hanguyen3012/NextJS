import { FAILURE, SUCCESS } from 'redux/constants';
import { verifyEmail } from '../constants/verifyEmail';

export function verifyEmailRegister(payload: any) {
  return {
    type: verifyEmail.VERIFY_EMAIL_REGISTER,
    payload,
  };
}

export function resentVerifyEmailRegister(payload: any) {
  return {
    type: verifyEmail.RESENT_VERIFY_EMAIL_REGISTER,
    payload,
  };
}

export function verifyEmailResetPassword(payload: any) {
  return {
    type: verifyEmail.VERIFY_EMAIL_RESET_PASSWORD,
    payload,
  };
}

export function resentVerifyEmailResetPassword(payload: any) {
  return {
    type: verifyEmail.RESENT_VERIFY_EMAIL_RESET_PASSWORD,
    payload,
  };
}
