import { modalConstants } from '../constants/modalConstants';

export function openModal(payload: any) {
  return {
    type: modalConstants.OPEN,
    payload,
  };
}

export function closeModal() {
  return {
    type: modalConstants.CLOSE,
  };
}
