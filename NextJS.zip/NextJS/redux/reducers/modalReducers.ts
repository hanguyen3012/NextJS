import { Action } from 'types';
import { modalConstants } from '../constants/modalConstants';

const initialState = {
  isModalOpen: false,
  page: '',
};

const reducer = (state = initialState, action: Action) => {
  switch (action.type) {
    case modalConstants.OPEN:
      return {
        ...state,
        isModalOpen: true,
        page: action.payload,
      };
    case modalConstants.CLOSE:
      return {
        ...state,
        isModalOpen: false,
        page: '',
      };
    default:
      return state;
  }
};

export default reducer;
