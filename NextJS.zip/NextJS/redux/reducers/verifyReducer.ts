import { FAILURE, SUCCESS } from 'redux/constants';
import { AUTH_PAGE } from 'shared/constant/common';
import { Action } from 'types';
import { verifyEmail } from '../constants/verifyEmail';

const initialState = {
  status: '',
  user: {},
  error: { isError: false },
};

const reducer = (state = initialState, action: Action) => {
  switch (action.type) {
    case verifyEmail.VERIFY_EMAIL_REGISTER:
    case verifyEmail.RESENT_VERIFY_EMAIL_REGISTER:
      return {
        ...state,
        status: '',
        user: action.payload,
      };
    case SUCCESS(verifyEmail.VERIFY_EMAIL_REGISTER):
      return {
        ...state,
        error: { isError: false },
        status: AUTH_PAGE.VERIFY_EMAIL_REGISTER,
      };
    case FAILURE(verifyEmail.VERIFY_EMAIL_REGISTER):
      return {
        ...state,
        status: AUTH_PAGE.VERIFY_EMAIL_REGISTER,
        error: {
          ...state.error,
          isError: true,
          statusCode: action?.payload?.response.statusCode,
          code: action?.payload?.response.code,
          message: action?.payload?.response.message,
          errorCode: action?.payload?.response.errorCode,
          errors: action?.payload?.response.errors,
        },
      };
    case verifyEmail.VERIFY_EMAIL_RESET_PASSWORD:
      return {
        ...state,
        status: '',
        user: action.payload,
      };
    case verifyEmail.RESENT_VERIFY_EMAIL_RESET_PASSWORD:
      return {
        ...state,
        status: verifyEmail.RESENT_VERIFY_EMAIL_RESET_PASSWORD,
        user: action.payload,
      };
    case SUCCESS(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD):
      return {
        ...state,
        error: { isError: false },
        status: SUCCESS(AUTH_PAGE.VERIFY_EMAIL_RESET_PASSWORD),
      };
    case FAILURE(verifyEmail.VERIFY_EMAIL_RESET_PASSWORD):
      return {
        ...state,
        status: FAILURE(AUTH_PAGE.VERIFY_EMAIL_RESET_PASSWORD),
        error: {
          ...state.error,
          isError: true,
          statusCode: action?.payload?.response.statusCode,
          code: action?.payload?.response.code,
          message: action?.payload?.response.message,
          errorCode: action?.payload?.response.errorCode,
          errors: action?.payload?.response.errors,
        },
      };
    default:
      return state;
  }
};

export default reducer;
