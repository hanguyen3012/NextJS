import { Action } from 'types/action';
import { authConstants } from '../constants/auth';
import { REQUEST, FAILURE, SUCCESS } from '../constants';

const initialState = {
  isLoading: false,
  email: '',
  accessToken: '',
  tokenType: '',
  account: '',
  error: { isError: false },
};

const reducer = (state = initialState, action: Action) => {
  const { payload } = action;
  switch (action.type) {
    case REQUEST(authConstants.LOGIN):
      return {
        ...state,
        isLoading: true,
      };
    case SUCCESS(authConstants.LOGIN):
      return {
        ...state,
        isLoading: false,
        accessToken: payload?.response.accessToken,
        tokenType: payload?.response.tokenType,
        account: payload?.response.account,
        error: { isError: false },
      };
    case FAILURE(authConstants.LOGIN):
      return {
        ...state,
        isLoading: false,
        error: {
          ...state.error,
          isError: true,
          statusCode: payload?.response.statusCode,
          code: payload?.response.code,
          message: payload?.response.message,
          errorCode: payload?.response.errorCode,
          errors: payload?.response.errors,
        },
      };
    case REQUEST(authConstants.FORGOT_PASSWORD):
      return {
        ...state,
        email: action.payload?.params?.email,
        isLoading: true,
      };
    case SUCCESS(authConstants.FORGOT_PASSWORD):
      return {
        ...state,
        isLoading: false,
        error: { isError: false },
      };
    case FAILURE(authConstants.FORGOT_PASSWORD):
      return {
        ...state,
        isLoading: false,
        error: {
          ...state.error,
          isError: true,
          statusCode: payload?.response.statusCode,
          code: payload?.response.code,
          message: payload?.response.message,
          errorCode: payload?.response.errorCode,
          errors: payload?.response.errors,
        },
      };
    default:
      return state;
  }
};

export default reducer;
